
const daysOfWeek = ["Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag", "Sonntag"];
const root = document.getElementById("root");

let mealPlan = Array(7).fill("");
let einkaufsliste = [];

function render() {
  root.innerHTML = "";

  const heading = document.createElement("h1");
  heading.textContent = "🧡 Familien Essensplaner";
  heading.className = "heading";
  root.appendChild(heading);

  const wochenplan = document.createElement("div");
  wochenplan.className = "card";
  wochenplan.innerHTML = "<h2>🍽️ Wochenplan</h2>";
  daysOfWeek.forEach((day, index) => {
    const row = document.createElement("div");
    row.className = "row";
    row.innerHTML = \`
      <label>\${day}:</label>
      <input type="text" value="\${mealPlan[index]}" placeholder="z. B. Lasagne" />
    \`;
    row.querySelector("input").addEventListener("input", (e) => {
      mealPlan[index] = e.target.value;
    });
    wochenplan.appendChild(row);
  });
  root.appendChild(wochenplan);

  const einkauf = document.createElement("div");
  einkauf.className = "card";
  einkauf.innerHTML = "<h2>🛒 Einkaufsliste</h2>";
  const input = document.createElement("input");
  input.placeholder = "Neues Produkt hinzufügen";
  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && input.value.trim()) {
      einkaufsliste.push(input.value.trim());
      input.value = "";
      render();
    }
  });
  einkauf.appendChild(input);

  const ul = document.createElement("ul");
  einkaufsliste.forEach((item, index) => {
    const li = document.createElement("li");
    li.textContent = item;
    const remove = document.createElement("button");
    remove.textContent = "Entfernen";
    remove.onclick = () => {
      einkaufsliste.splice(index, 1);
      render();
    };
    li.appendChild(remove);
    ul.appendChild(li);
  });
  einkauf.appendChild(ul);

  root.appendChild(einkauf);
}

render();
