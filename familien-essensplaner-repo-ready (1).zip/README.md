# Familien Essensplaner

Dies ist eine Next.js-App zur Planung von Familienessen.

## Lokale Entwicklung

```bash
npm install
npm run dev
```

## Deployment

Einfach zu Vercel deployen (wird automatisch erkannt).

